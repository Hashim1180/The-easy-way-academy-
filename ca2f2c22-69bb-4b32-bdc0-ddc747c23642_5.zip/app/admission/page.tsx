'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function AdmissionPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://readdy.ai/api/search-image?query=Professional%20admissions%20office%20for%20German%20language%20academy%20with%20friendly%20staff%20consulting%20students%2C%20modern%20educational%20counseling%20room%20with%20German%20learning%20materials%2C%20welcoming%20academic%20environment%20with%20certificates%20and%20achievement%20displays%20on%20walls&width=1920&height=800&seq=admission-hero&orientation=landscape')`
        }}
      >
        <div className="text-center text-white max-w-4xl mx-auto px-6">
          <h1 className="text-5xl font-bold mb-6">Admission Process</h1>
          <p className="text-xl">
            Your journey to mastering German starts here. Learn about our simple admission process.
          </p>
        </div>
      </section>

      {/* Admission Steps */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How to Apply</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Follow these simple steps to join The Easy Way Academy and start your German learning journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Choose Your Course</h3>
              <p className="text-gray-600">
                Browse our course offerings and select the German level that matches your current skills and goals.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Take Placement Test</h3>
              <p className="text-gray-600">
                Complete our free online placement test to ensure you're placed in the right level for optimal learning.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Submit Application</h3>
              <p className="text-gray-600">
                Fill out our enrollment form with your personal details, course preferences, and learning goals.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">4</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Start Learning</h3>
              <p className="text-gray-600">
                Receive confirmation, complete payment, and begin your German learning adventure with us.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Requirements */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Admission Requirements</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Age Requirement</h3>
                    <p className="text-gray-600">Minimum age of 16 years for all courses. No maximum age limit.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Language Skills</h3>
                    <p className="text-gray-600">No prior German knowledge required for beginner courses. Placement test determines your level.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Documentation</h3>
                    <p className="text-gray-600">Valid ID or passport required for enrollment. Student visa support available for international students.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Technology</h3>
                    <p className="text-gray-600">For online courses: stable internet connection, computer/tablet with camera and microphone.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                    <i className="ri-check-line text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Commitment</h3>
                    <p className="text-gray-600">Dedication to attend classes regularly and complete assignments for best learning outcomes.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-xl">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Quick Facts</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Application Fee</span>
                  <span className="text-gray-900 font-semibold">Free</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Placement Test</span>
                  <span className="text-gray-900 font-semibold">Free Online</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Response Time</span>
                  <span className="text-gray-900 font-semibold">24 Hours</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Class Size</span>
                  <span className="text-gray-900 font-semibold">Max 12 Students</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium text-gray-700">Course Duration</span>
                  <span className="text-gray-900 font-semibold">8-18 Weeks</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="font-medium text-gray-700">Certificates</span>
                  <span className="text-gray-900 font-semibold">Provided</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Placement Test */}
      <section className="py-20 bg-blue-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Free Placement Test</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ensure you're placed in the right course level with our comprehensive placement assessment
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-questionnaire-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Grammar & Vocabulary</h3>
              <p className="text-gray-600">
                Test your current knowledge of German grammar rules, sentence structure, and vocabulary range.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-volume-up-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Listening Comprehension</h3>
              <p className="text-gray-600">
                Evaluate your ability to understand spoken German in various contexts and situations.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-file-text-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Reading Comprehension</h3>
              <p className="text-gray-600">
                Assess your reading skills and understanding of German texts at different difficulty levels.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 inline-block">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Take Your Placement Test</h3>
              <p className="text-gray-600 mb-6">
                The test takes approximately 20-30 minutes to complete. Results are available immediately.
              </p>
              <Link href="/placement-test" className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                Start Test Now
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Tuition & Payment */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Tuition & Payment Options</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Flexible payment plans to make quality German education accessible to everyone
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-xl border border-blue-200">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-credit-card-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Full Payment</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  5% discount on total fees
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  One-time payment before course start
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  No additional processing fees
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Priority in class selection
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-xl border border-green-200">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-calendar-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Monthly Installments</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Split payment over course duration
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  No interest charges
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Automatic monthly deduction
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Flexible payment dates
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-xl border border-purple-200">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-scholarship-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Financial Aid</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Need-based scholarships available
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Student discount programs
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Corporate group rates
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Payment plan consultations
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-8 rounded-xl mt-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Accepted Payment Methods</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center mx-auto mb-3 shadow-sm">
                  <i className="ri-bank-card-line text-2xl text-gray-700"></i>
                </div>
                <span className="text-gray-700 font-medium">Credit Cards</span>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center mx-auto mb-3 shadow-sm">
                  <i className="ri-bank-line text-2xl text-gray-700"></i>
                </div>
                <span className="text-gray-700 font-medium">Bank Transfer</span>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center mx-auto mb-3 shadow-sm">
                  <i className="ri-paypal-line text-2xl text-gray-700"></i>
                </div>
                <span className="text-gray-700 font-medium">PayPal</span>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center mx-auto mb-3 shadow-sm">
                  <i className="ri-secure-payment-line text-2xl text-gray-700"></i>
                </div>
                <span className="text-gray-700 font-medium">SEPA Direct</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Apply?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Start your German learning journey today. Our admissions team is ready to help you succeed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/enrollment" className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
              Apply Now
            </Link>
            <Link href="/contact" className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
              Contact Admissions
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
