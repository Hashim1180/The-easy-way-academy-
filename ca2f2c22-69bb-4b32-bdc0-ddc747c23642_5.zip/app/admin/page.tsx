'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';
import Link from 'next/link';

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginData, setLoginData] = useState({
    username: '',
    password: ''
  });
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple authentication (in real app, use proper authentication)
    if (loginData.username === 'admin' && loginData.password === 'admin123') {
      setIsAuthenticated(true);
    } else {
      alert('Invalid credentials. Use username: admin, password: admin123');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setLoginData({ username: '', password: '' });
  };

  // Sample data for demonstration
  const dashboardStats = {
    totalEnrollments: 247,
    activeCourses: 12,
    totalStudents: 892,
    pendingApplications: 23
  };

  const recentEnrollments = [
    { id: 1, name: 'Maria Schmidt', course: 'B1 - Intermediate', date: '2024-01-15', status: 'Confirmed' },
    { id: 2, name: 'John Miller', course: 'A2 - Elementary', date: '2024-01-14', status: 'Pending' },
    { id: 3, name: 'Anna Weber', course: 'C1 - Advanced', date: '2024-01-14', status: 'Confirmed' },
    { id: 4, name: 'David Brown', course: 'Business German', date: '2024-01-13', status: 'Pending' },
    { id: 5, name: 'Sarah Johnson', course: 'A1 - Beginner', date: '2024-01-13', status: 'Confirmed' }
  ];

  const courses = [
    { id: 1, level: 'A1 - Beginner', students: 45, capacity: 50, status: 'Active' },
    { id: 2, level: 'A2 - Elementary', students: 38, capacity: 40, status: 'Active' },
    { id: 3, level: 'B1 - Intermediate', students: 42, capacity: 45, status: 'Active' },
    { id: 4, level: 'B2 - Upper-Intermediate', students: 35, capacity: 40, status: 'Active' },
    { id: 5, level: 'C1 - Advanced', students: 28, capacity: 30, status: 'Active' },
    { id: 6, level: 'Business German', students: 22, capacity: 25, status: 'Active' }
  ];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Header />
        
        <div className="flex items-center justify-center py-20">
          <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full mx-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-admin-line text-white text-2xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Admin Login</h1>
              <p className="text-gray-600">Access the admin panel for The Easy Way Academy</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username
                </label>
                <input
                  type="text"
                  value={loginData.username}
                  onChange={(e) => setLoginData(prev => ({ ...prev, username: e.target.value }))}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  placeholder="Enter username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  value={loginData.password}
                  onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  placeholder="Enter password"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Login to Admin Panel
              </button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Demo Credentials:</strong><br />
                Username: admin<br />
                Password: admin123
              </p>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Admin Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600">Manage your academy efficiently</p>
            </div>
            <button
              onClick={handleLogout}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-logout-box-line mr-2"></i>
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Sidebar Navigation */}
          <div className="w-64 bg-white rounded-xl shadow-sm p-6">
            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'dashboard' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <i className="ri-dashboard-line mr-2"></i>
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab('enrollments')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'enrollments' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <i className="ri-user-add-line mr-2"></i>
                Enrollments
              </button>
              <button
                onClick={() => setActiveTab('courses')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'courses' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <i className="ri-book-line mr-2"></i>
                Courses
              </button>
              <button
                onClick={() => setActiveTab('students')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'students' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <i className="ri-group-line mr-2"></i>
                Students
              </button>
              <button
                onClick={() => setActiveTab('messages')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'messages' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <i className="ri-message-line mr-2"></i>
                Messages
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'settings' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <i className="ri-settings-line mr-2"></i>
                Settings
              </button>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'dashboard' && (
              <div className="space-y-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Total Enrollments</p>
                        <p className="text-2xl font-bold text-gray-900">{dashboardStats.totalEnrollments}</p>
                      </div>
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className="ri-user-add-line text-blue-600 text-xl"></i>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Active Courses</p>
                        <p className="text-2xl font-bold text-gray-900">{dashboardStats.activeCourses}</p>
                      </div>
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i className="ri-book-line text-green-600 text-xl"></i>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Total Students</p>
                        <p className="text-2xl font-bold text-gray-900">{dashboardStats.totalStudents}</p>
                      </div>
                      <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i className="ri-group-line text-purple-600 text-xl"></i>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm">Pending Applications</p>
                        <p className="text-2xl font-bold text-gray-900">{dashboardStats.pendingApplications}</p>
                      </div>
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                        <i className="ri-time-line text-orange-600 text-xl"></i>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Enrollments */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                  <div className="p-6 border-b border-gray-100">
                    <h2 className="text-xl font-semibold text-gray-900">Recent Enrollments</h2>
                  </div>
                  <div className="p-6">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="text-left text-gray-600 text-sm">
                            <th className="pb-4">Student Name</th>
                            <th className="pb-4">Course</th>
                            <th className="pb-4">Date</th>
                            <th className="pb-4">Status</th>
                            <th className="pb-4">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="space-y-2">
                          {recentEnrollments.map((enrollment, index) => (
                            <tr key={index} className="border-t border-gray-100">
                              <td className="py-4 font-medium text-gray-900">{enrollment.name}</td>
                              <td className="py-4 text-gray-600">{enrollment.course}</td>
                              <td className="py-4 text-gray-600">{enrollment.date}</td>
                              <td className="py-4">
                                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                  enrollment.status === 'Confirmed' 
                                    ? 'bg-green-100 text-green-800' 
                                    : 'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {enrollment.status}
                                </span>
                              </td>
                              <td className="py-4">
                                <button className="text-blue-600 hover:text-blue-700 cursor-pointer mr-4">
                                  <i className="ri-eye-line"></i>
                                </button>
                                <button className="text-green-600 hover:text-green-700 cursor-pointer">
                                  <i className="ri-check-line"></i>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'courses' && (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-semibold text-gray-900">Course Management</h2>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                    <i className="ri-add-line mr-2"></i>
                    Add New Course
                  </button>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                  <div className="p-6">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="text-left text-gray-600 text-sm">
                            <th className="pb-4">Course Level</th>
                            <th className="pb-4">Students</th>
                            <th className="pb-4">Capacity</th>
                            <th className="pb-4">Status</th>
                            <th className="pb-4">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {courses.map((course, index) => (
                            <tr key={index} className="border-t border-gray-100">
                              <td className="py-4 font-medium text-gray-900">{course.level}</td>
                              <td className="py-4 text-gray-600">{course.students}</td>
                              <td className="py-4 text-gray-600">{course.capacity}</td>
                              <td className="py-4">
                                <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  {course.status}
                                </span>
                              </td>
                              <td className="py-4">
                                <button className="text-blue-600 hover:text-blue-700 cursor-pointer mr-4">
                                  <i className="ri-edit-line"></i>
                                </button>
                                <button className="text-gray-600 hover:text-gray-700 cursor-pointer mr-4">
                                  <i className="ri-eye-line"></i>
                                </button>
                                <button className="text-red-600 hover:text-red-700 cursor-pointer">
                                  <i className="ri-delete-bin-line"></i>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'enrollments' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="p-6 border-b border-gray-100">
                  <h2 className="text-xl font-semibold text-gray-900">All Enrollments</h2>
                </div>
                <div className="p-6">
                  <p className="text-gray-600">Detailed enrollment management coming soon...</p>
                </div>
              </div>
            )}

            {activeTab === 'students' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="p-6 border-b border-gray-100">
                  <h2 className="text-xl font-semibold text-gray-900">Student Management</h2>
                </div>
                <div className="p-6">
                  <p className="text-gray-600">Student profiles and progress tracking coming soon...</p>
                </div>
              </div>
            )}

            {activeTab === 'messages' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="p-6 border-b border-gray-100">
                  <h2 className="text-xl font-semibold text-gray-900">Messages & Communications</h2>
                </div>
                <div className="p-6">
                  <p className="text-gray-600">Contact form submissions and messaging system coming soon...</p>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="p-6 border-b border-gray-100">
                  <h2 className="text-xl font-semibold text-gray-900">Academy Settings</h2>
                </div>
                <div className="p-6">
                  <p className="text-gray-600">System configuration and academy settings coming soon...</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}