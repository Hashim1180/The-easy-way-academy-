'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function CoursesPage() {
  const courses = [
    {
      level: 'A1 - Beginner',
      duration: '8 weeks',
      price: '€299',
      schedule: 'Mon, Wed, Fri - 18:00-19:30',
      description: 'Perfect for complete beginners. Learn basic German vocabulary, grammar, and pronunciation.',
      features: ['Basic vocabulary (500+ words)', 'Present tense grammar', 'Simple conversations', 'German alphabet & pronunciation'],
      color: 'bg-green-500',
      icon: 'ri-seedling-line'
    },
    {
      level: 'A2 - Elementary',
      duration: '10 weeks',
      price: '€349',
      schedule: 'Tue, Thu, Sat - 19:00-20:30',
      description: 'Build on your basics and start having real conversations in German.',
      features: ['Extended vocabulary (1000+ words)', 'Past tense & future tense', 'Travel & shopping scenarios', 'Cultural insights'],
      color: 'bg-blue-500',
      icon: 'ri-plant-line'
    },
    {
      level: 'B1 - Intermediate',
      duration: '12 weeks',
      price: '€399',
      schedule: 'Mon, Wed, Fri - 19:00-20:30',
      description: 'Express yourself confidently on familiar topics and handle most travel situations.',
      features: ['Complex grammar structures', 'Opinion expression', 'Job interview preparation', 'Media comprehension'],
      color: 'bg-yellow-500',
      icon: 'ri-tree-line'
    },
    {
      level: 'B2 - Upper-Intermediate',
      duration: '14 weeks',
      price: '€449',
      schedule: 'Tue, Thu - 18:30-20:00',
      description: 'Discuss complex topics and understand detailed texts about current events.',
      features: ['Advanced grammar mastery', 'Academic writing', 'Business German basics', 'Literature analysis'],
      color: 'bg-orange-500',
      icon: 'ri-mountain-line'
    },
    {
      level: 'C1 - Advanced',
      duration: '16 weeks',
      price: '€499',
      schedule: 'Mon, Wed - 19:30-21:00',
      description: 'Express ideas fluently and understand implicit meanings in complex texts.',
      features: ['Nuanced expression', 'Professional presentations', 'Advanced writing skills', 'Cultural discussions'],
      color: 'bg-purple-500',
      icon: 'ri-rocket-line'
    },
    {
      level: 'C2 - Proficiency',
      duration: '18 weeks',
      price: '€549',
      schedule: 'Sat - 10:00-13:00',
      description: 'Achieve native-like understanding and expression in all contexts.',
      features: ['Master-level fluency', 'Academic research skills', 'Professional certification prep', 'Native-like expression'],
      color: 'bg-red-500',
      icon: 'ri-medal-line'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://readdy.ai/api/search-image?query=Students%20learning%20German%20language%20in%20modern%20classroom%20with%20textbooks%20and%20interactive%20whiteboard%2C%20diverse%20group%20of%20adult%20learners%20engaged%20in%20German%20language%20lesson%20with%20professional%20teacher%2C%20bright%20educational%20environment%20with%20German%20cultural%20elements&width=1920&height=800&seq=courses-hero&orientation=landscape')`
        }}
      >
        <div className="text-center text-white max-w-4xl mx-auto px-6">
          <h1 className="text-5xl font-bold mb-6">Our German Courses</h1>
          <p className="text-xl mb-8">
            Choose the perfect course for your German learning journey. From absolute beginner to advanced proficiency.
          </p>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-shadow">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 ${course.color} rounded-lg flex items-center justify-center mr-4`}>
                      <i className={`${course.icon} text-white text-xl`}></i>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{course.level}</h3>
                      <p className="text-gray-600">{course.duration}</p>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-6">{course.description}</p>
                  
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">What you'll learn:</h4>
                    <ul className="space-y-2">
                      {course.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center text-gray-600">
                          <i className="ri-check-line text-green-500 mr-2"></i>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="border-t border-gray-100 pt-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <div className="text-2xl font-bold text-blue-600">{course.price}</div>
                        <div className="text-sm text-gray-600">{course.schedule}</div>
                      </div>
                    </div>
                    
                    <Link href="/enrollment" className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors cursor-pointer text-center block whitespace-nowrap">
                      Enroll Now
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Special Programs */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Special Programs</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Specialized courses designed for specific needs and goals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-xl border border-blue-200">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-briefcase-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Business German</h3>
              <p className="text-gray-700 text-center mb-6">
                Master professional German for workplace communication, presentations, and business correspondence.
              </p>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600 mb-2">€699</div>
                <div className="text-sm text-gray-600 mb-4">12 weeks intensive</div>
                <Link href="/enrollment" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                  Learn More
                </Link>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-xl border border-green-200">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-graduation-cap-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Exam Preparation</h3>
              <p className="text-gray-700 text-center mb-6">
                Prepare for official German certifications: Goethe, TestDaF, telc, and DSH exams.
              </p>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 mb-2">€599</div>
                <div className="text-sm text-gray-600 mb-4">8 weeks intensive</div>
                <Link href="/enrollment" className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
                  Learn More
                </Link>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-xl border border-purple-200">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-user-2-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Private Tutoring</h3>
              <p className="text-gray-700 text-center mb-6">
                One-on-one lessons tailored to your specific needs and learning pace with expert instructors.
              </p>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600 mb-2">€45/hr</div>
                <div className="text-sm text-gray-600 mb-4">Flexible schedule</div>
                <Link href="/contact" className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors cursor-pointer whitespace-nowrap">
                  Book Session
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Start Learning?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Choose your course and begin your German language journey today
          </p>
          <Link href="/enrollment" className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
            Enroll Today
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}